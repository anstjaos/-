package com.example.lg.blockchainui;

public interface SetFragmentData{
    void setFragmentData(int fragment_no);

}